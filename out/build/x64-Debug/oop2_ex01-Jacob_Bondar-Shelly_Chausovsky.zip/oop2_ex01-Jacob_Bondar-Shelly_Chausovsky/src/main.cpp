#include <iostream>
#include "Calculator.h"

int main()
{
	auto calc = Calculator();
	calc.run();

	exit(EXIT_SUCCESS);
}